let skills: (string | number)[] = ['Hỏi Dân IT', 25];
skills.push('coding');
skills.push(69);

//tuple: dataType/size/order
let skills2: [string, number] = ['Hỏi Dân IT', 25];

let skills3: [boolean, string, number?];

skills3 = [true, 'Eric'];


