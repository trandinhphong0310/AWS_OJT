enum API_STATUS {
    PENDDING,
    FULFILLED = "FULFILLED asfdasfasf",
    REJECTED = "FULFILLED" //PROMISE
}

//constant
//java

let a1 = API_STATUS.PENDDING;
let a2 = API_STATUS.FULFILLED;

//frontend : syntax
console.log(">>> a1 = ", a1, " a2 = ", a2)