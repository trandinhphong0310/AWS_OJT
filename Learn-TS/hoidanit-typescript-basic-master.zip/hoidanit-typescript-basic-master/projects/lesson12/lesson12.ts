let test: (number | string)[] = ['hoi dan it', 69];

test.push('hoi dan it');

test.push(25);

console.log(">>> check array: ", test)