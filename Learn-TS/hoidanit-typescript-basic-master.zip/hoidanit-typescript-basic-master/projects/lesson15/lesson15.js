let name = 'eric'; //string

name = 35; //number

name = false; //boolean