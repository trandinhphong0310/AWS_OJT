let namev2: any = 'Eric'; // any everywhere

namev2 = true;

