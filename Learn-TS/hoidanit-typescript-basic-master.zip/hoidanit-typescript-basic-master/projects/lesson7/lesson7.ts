let count: string = "Hoi Dan IT";

console.log(">>> check count 0 = ", count)

let test = ['eric', 'hoi danit', 'typescirpt', 96];

test.push(25);