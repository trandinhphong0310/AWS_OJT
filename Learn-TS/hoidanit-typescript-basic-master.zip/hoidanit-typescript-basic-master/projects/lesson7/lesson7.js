let count0 = 10;

count0 = 'eric';

console.log(">>> check count 0 = ", count0)
