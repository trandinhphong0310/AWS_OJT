let count = 69; //int long => number
let score = 9.6; //float double => number
