let test: number = 9.6;

const a1: number = 123;

let a2: number;

test = 999999999999999999999999999999999999;


