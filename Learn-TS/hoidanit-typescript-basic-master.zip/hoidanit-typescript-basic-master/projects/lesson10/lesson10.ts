let status1: boolean = false;
let check1: boolean = true;
let pro: boolean = Boolean("");

console.log(">>> check pro: ", pro)

