let name2: string = ` và "Hỏi Dân IT"`;
let name3 = `Eric ${name2}`; //template strings js

console.log(">>> check name = ", name3)
// Eric và "Hỏi Dân IT"