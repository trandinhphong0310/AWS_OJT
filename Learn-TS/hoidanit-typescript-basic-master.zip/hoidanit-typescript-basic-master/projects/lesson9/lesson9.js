let name = "Eric";
let name1 = 'Eric';
