

let names2: string[] = ['Eric', 'Hỏi Dân IT', 'Typescript']
// array chỉ bao gồm string
names2.push("25") //error ?

console.log(">>> check name 2: ", names2)
