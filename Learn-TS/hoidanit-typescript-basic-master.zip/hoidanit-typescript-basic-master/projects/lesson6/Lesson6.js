// let count = 1; //ok

// count = 'name'; //error ?

// console.log(">>> check count: ", count)

let names = ['Eric', 'Hỏi Dân IT', 'Typescript'] // array chỉ bao gồm string
names.push(25) //error ?

console.log(">>> check names: ", names)


