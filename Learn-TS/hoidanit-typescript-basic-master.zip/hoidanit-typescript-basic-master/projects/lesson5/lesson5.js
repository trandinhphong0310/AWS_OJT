const name = 'Eric';

console.log("length = ", name.length)
console.log('upPerCasse = ', name.toUpperCase())
