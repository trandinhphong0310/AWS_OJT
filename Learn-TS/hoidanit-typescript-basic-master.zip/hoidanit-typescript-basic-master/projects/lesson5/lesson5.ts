const nameTS1 = 'Eric';

console.log('length = ', nameTS1.length)

console.log('upPerCasse = ', nameTS1.toUpperCase())

