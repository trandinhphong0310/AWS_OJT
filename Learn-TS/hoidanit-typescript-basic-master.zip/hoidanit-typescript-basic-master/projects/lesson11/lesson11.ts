// let person: object;

// let mine3 = {name : 'hoi dan it'}

// person = { name: 'Eric'};
// person = 'Eric'

// let pro = {
//     name: "Eric", //string
//     age: 25 //age
// }

let pro1: {
    name: string,
    age: number
} = {
    name: "Eric", //string
    age: 25 //age
}

