let mine = {};
mine = { name: "Eric" };

mine.address = "Hỏi Dân IT";

console.log(">>> check mine: ", mine)