let count1 = 1; //ok

// count1 = 'name'; //error ?

console.log(">>> check name: ")

let names1 = ['Eric', 'Hỏi Dân IT', 'Typescript'] // array chỉ bao gồm string
// names1.push(25) //error ?
