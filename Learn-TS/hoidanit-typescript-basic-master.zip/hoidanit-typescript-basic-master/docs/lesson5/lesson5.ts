const nameTS = 'Eric';

console.log('length = ',)

console.log('upPerCasse = ',)

