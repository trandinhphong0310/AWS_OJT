const name = 'Eric';

console.log("length = ",)
console.log('upPerCasse = ',)
