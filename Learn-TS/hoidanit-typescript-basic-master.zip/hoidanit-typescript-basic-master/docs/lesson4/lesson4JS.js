
//perfect
const sum = (x, y) => {
    return x + y;
}

sum(5, 10); //15

//need to validate
const sum2 = (x, y) => {
    //validate: x, y are numbers ???
    return x + y;
}

sum('name', 20);
