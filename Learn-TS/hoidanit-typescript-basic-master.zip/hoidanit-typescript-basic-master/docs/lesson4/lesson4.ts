const sum3 = (x: number, y: number) => {
    return x + y;
}

//no error
console.log(sum3(5, 10));

//error
// console.log(sum3(5, '15'));