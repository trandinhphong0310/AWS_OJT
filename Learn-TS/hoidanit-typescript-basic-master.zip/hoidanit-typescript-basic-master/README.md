### Typescript basic (Youtube Channel: Hỏi Dân IT)


#### Full playlist here: https://www.youtube.com/playlist?list=PLncHg6Kn2JT5emvXmG6kgeGkrQjRqxsb4